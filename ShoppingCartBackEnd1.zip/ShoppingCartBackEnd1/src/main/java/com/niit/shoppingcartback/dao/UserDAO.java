package com.niit.shoppingcartback.dao;

import java.util.List;

import com.niit.shoppingcartback.model.User;

public interface UserDAO {
	
	public User getUser(String id);
	public void saveOrUpdate(User user);
	public void delete(String id);
	public List<User> list();
	public boolean isValidUser(String name,String password);

}
