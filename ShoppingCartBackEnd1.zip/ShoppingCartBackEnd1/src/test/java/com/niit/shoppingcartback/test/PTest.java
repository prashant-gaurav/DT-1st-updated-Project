package com.niit.shoppingcartback.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartback.dao.ProductDAO;
import com.niit.shoppingcartback.model.Product;

public class PTest {

	public static void main(String[] args) {
			AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
			context.scan("com.niit.shoppingcartback");
			context.refresh();
			
			
			ProductDAO productDAO =(ProductDAO) context.getBean("productDAO");
			
			Product product= (Product) context.getBean("product");
			
			
			
			product.setId("P003");
			product.setName("pghi");
			product.setPrice(900);
			product.setDescription("P003pghi");
			product.setCategory_id("C001");
			product.setSupplier_id("S001");
			
			
			//productDAO.delete("id");
			
			//System.out.println(productDAO.getProduct("P002").getName());
			
		
		    productDAO.saveOrUpdate(product);
			
			/*if(   productDAO.getProduct("P001") ==null)
			  {
				  System.out.println("Category does not exist");
			  }
			  else
			  {
				  System.out.println("Category exist .. the details are ..");
				  System.out.println();
			  }*/
				
					}
}
