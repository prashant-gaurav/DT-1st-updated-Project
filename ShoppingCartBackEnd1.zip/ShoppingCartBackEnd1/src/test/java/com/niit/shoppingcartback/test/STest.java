package com.niit.shoppingcartback.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartback.dao.SupplierDAO;
import com.niit.shoppingcartback.model.Supplier;

public class STest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.shoppingcartback");
		context.refresh();
		
		SupplierDAO supplierDAO =(SupplierDAO) context.getBean("supplierDAO");
		System.out.println("success");
		
		Supplier supplier=(Supplier) context.getBean("supplier");
		System.out.println("SUCCESS");
		
		supplier.setId("S002");
		supplier.setName("sdef");
		supplier.setAddress("S002sdef");
		supplier.setMob_no(222);
		
		supplierDAO.saveOrUpdate(supplier);
		
		//supplierDAO.delete("S002");
		
		//System.out.println(supplierDAO.getSupplier("S001").getName());
		if(   supplierDAO.getSupplier("S001") ==null)
		  {
			  System.out.println("Category does not exist");
		  }
		  else
		  {
			  System.out.println("Category exist .. the details are ..");
			  System.out.println();
		  
			
				}

	}
		

	}


